# SRISHTI AI OS Backend - Deployment Guide

## Quick Start

### Local Development

```bash
# 1. Clone repository
git clone https://github.com/srishti/srishti-ai-os.git
cd srishti-backend

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp config/.env.example config/.env
# Edit config/.env with your API keys

# 5. Initialize database
python -c "from backend.app import app, db; app.app_context().push(); db.create_all()"

# 6. Run development server
python backend/app.py
```

Access at: `http://localhost:10000`

---

## Production Deployment

### Option 1: Render (Recommended)

1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Deploy SRISHTI backend"
   git push origin main
   ```

2. **Create Render Service**
   - Go to https://render.com
   - Connect GitHub repository
   - Select `deployment/render.yaml`
   - Configure environment variables
   - Deploy

3. **Set Environment Variables**
   - OPENAI_API_KEY
   - ANTHROPIC_API_KEY
   - GOOGLE_API_KEY
   - DATABASE_URL
   - REDIS_URL

### Option 2: Docker

```bash
# Build image
docker build -t srishti-backend:latest .

# Run container
docker run -d \
  -p 10000:10000 \
  -e FLASK_ENV=production \
  -e DATABASE_URL=postgresql://user:pass@db:5432/srishti \
  -e REDIS_URL=redis://redis:6379 \
  srishti-backend:latest
```

### Option 3: Traditional Server

```bash
# Install dependencies
pip install -r requirements.txt

# Run with Gunicorn
gunicorn backend.app:app \
  --bind 0.0.0.0:10000 \
  --workers 4 \
  --timeout 120 \
  --access-logfile - \
  --error-logfile -
```

### Option 4: AWS EC2

```bash
# Launch EC2 instance (Ubuntu 22.04)
# SSH into instance

# Install Python and dependencies
sudo apt update
sudo apt install python3-pip python3-venv postgresql redis-server

# Clone and setup
git clone https://github.com/srishti/srishti-ai-os.git
cd srishti-backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Configure systemd service
sudo cp deployment/srishti-backend.service /etc/systemd/system/
sudo systemctl enable srishti-backend
sudo systemctl start srishti-backend
```

---

## Environment Variables

Create `config/.env`:

```env
# Flask
FLASK_ENV=production
FLASK_DEBUG=False
SECRET_KEY=your-secret-key-here

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/srishti_db

# API Keys
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_API_KEY=...
COHERE_API_KEY=...

# Redis
REDIS_URL=redis://localhost:6379/0

# Server
HOST=0.0.0.0
PORT=10000
WORKERS=4

# CORS
CORS_ORIGINS=https://srishti.ai,https://app.srishti.ai

# Logging
LOG_LEVEL=INFO
LOG_FILE=logs/srishti.log
```

---

## Database Setup

### PostgreSQL

```bash
# Create database
createdb srishti_db

# Create user
createuser srishti_user
psql -c "ALTER USER srishti_user WITH PASSWORD 'secure_password';"
psql -c "GRANT ALL PRIVILEGES ON DATABASE srishti_db TO srishti_user;"

# Initialize schema
python -c "from backend.app import app, db; app.app_context().push(); db.create_all()"
```

### SQLite (Development)

```bash
# Database automatically created at database/srishti.db
python -c "from backend.app import app, db; app.app_context().push(); db.create_all()"
```

---

## Monitoring

### Health Check

```bash
curl http://localhost:10000/health
```

Response:
```json
{
  "status": "healthy",
  "timestamp": "2026-03-31T10:00:00",
  "version": "1.0.0",
  "environment": "production"
}
```

### Logs

```bash
# View logs
tail -f logs/srishti.log

# Filter errors
grep ERROR logs/srishti.log
```

### Metrics

```bash
# Get dashboard
curl http://localhost:10000/api/analytics/dashboard
```

---

## Performance Optimization

### 1. Database Indexing

```sql
CREATE INDEX idx_messages_user_id ON messages(user_id);
CREATE INDEX idx_messages_created_at ON messages(created_at);
CREATE INDEX idx_actions_user_id ON actions(user_id);
CREATE INDEX idx_agents_user_id ON agents(user_id);
```

### 2. Caching

```python
# Redis caching enabled for:
# - Chat history
# - Agent responses
# - Analytics data
# - User sessions
```

### 3. Load Balancing

```nginx
upstream srishti_backend {
    server localhost:10000;
    server localhost:10001;
    server localhost:10002;
}

server {
    listen 80;
    server_name api.srishti.ai;
    
    location / {
        proxy_pass http://srishti_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

---

## Security

### SSL/TLS

```bash
# Generate self-signed certificate
openssl req -x509 -newkey rsa:4096 -nodes -out cert.pem -keyout key.pem -days 365

# Use with Gunicorn
gunicorn backend.app:app \
  --certfile=cert.pem \
  --keyfile=key.pem \
  --bind 0.0.0.0:10000
```

### Rate Limiting

```python
# Configured in app.py
# Default: 1000 requests per hour per IP
```

### API Keys

- Store in environment variables
- Never commit to repository
- Rotate regularly
- Use separate keys for different environments

---

## Backup & Recovery

### Database Backup

```bash
# PostgreSQL
pg_dump srishti_db > backup.sql

# Restore
psql srishti_db < backup.sql
```

### Automated Backups

```bash
# Daily backup script
0 2 * * * pg_dump srishti_db | gzip > /backups/srishti_$(date +\%Y\%m\%d).sql.gz
```

---

## Troubleshooting

### Port Already in Use

```bash
# Find process using port 10000
lsof -i :10000

# Kill process
kill -9 <PID>
```

### Database Connection Error

```bash
# Test connection
psql -U srishti_user -d srishti_db -h localhost
```

### Memory Issues

```bash
# Check memory usage
free -h

# Restart service
sudo systemctl restart srishti-backend
```

### High CPU Usage

```bash
# Monitor processes
top

# Check logs for errors
tail -f logs/srishti.log
```

---

## Scaling

### Horizontal Scaling

1. Run multiple instances
2. Use load balancer (Nginx, HAProxy)
3. Share database and Redis
4. Use CDN for static assets

### Vertical Scaling

1. Increase server resources (CPU, RAM)
2. Optimize database queries
3. Enable caching
4. Use connection pooling

---

## Updates & Maintenance

### Dependency Updates

```bash
pip install --upgrade -r requirements.txt
```

### Code Updates

```bash
git pull origin main
pip install -r requirements.txt
systemctl restart srishti-backend
```

### Database Migrations

```bash
# Backup first
pg_dump srishti_db > backup.sql

# Run migrations
python migrate.py

# Verify
python -c "from backend.app import app, db; app.app_context().push(); db.create_all()"
```

---

## Support

For deployment issues:
- Check logs: `tail -f logs/srishti.log`
- Review documentation: `docs/README.md`
- Contact: support@srishti.ai

---

**SRISHTI AI OS - Production Ready**
